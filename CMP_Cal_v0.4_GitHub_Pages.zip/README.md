# CMP Cal — PWA v0.4

Prototipo móvil en español y tema oscuro. La versión 0.4 refuerza la conversión de concentración desde la etiqueta, la invalidación de resultados antiguos, la flexibilidad de frecuencia y las pruebas. Mantiene separación de módulos, validación matemática, experiencia táctil, accesibilidad básica y caché offline. **No contiene pautas terapéuticas ni constituye un sistema de prescripción o apoyo a decisiones clínicas validado.**

## Estado real

- **Dosis pediátricas:** convierte una dosis previamente prescrita en mg/kg/dosis o mg/kg/día a mg y mL por administración. La concentración se obtiene de la relación exacta de etiqueta en mg y mL (ejemplo: 125 mg en 5 mL = 25 mg/mL). La frecuencia se introduce como entero de 1–24. Exige confirmar que la dosis ya fue indicada. No valida medicamento, indicación, máximos ni intervalo clínico. Los resultados se borran al editar los datos.
- **Hidratación pediátrica:** estimación teórica Holliday–Segar o 4-2-1, para 8 o 24 horas. Exige confirmar que no es un neonato. No calcula déficit, bolos, pérdidas, composición, electrolitos ni restricciones.
- **Electrolitos:** KCl o NaCl anhidros, únicamente cuando la etiqueta/ficha técnica confirma concentración en % m/v. Exige confirmación del operador; no interpreta automáticamente la etiqueta ni calcula preparación o infusión.
- **Neonatología:** ficha separada que valida semanas gestacionales completas (20–45), días posnatales (0–28) y peso actual (0.1–10 kg). No comparte la calculadora pediátrica y no calcula dosis ni líquidos.
- **Datos:** no se guardan en localStorage/IndexedDB ni se transmiten al servidor. Los campos desaparecen al cerrar o recargar la página.
- **PWA:** caché versionado del shell de la aplicación (v0.4); navegación con fallback offline y recursos del mismo origen. Requiere HTTPS (o localhost durante desarrollo) para registrar el service worker.

## Estructura

```text
cmp_cal_pwa/
├── index.html
├── styles.css
├── app.js
├── calculations.js
├── manifest.webmanifest
├── sw.js
├── icon-192.png
├── icon-512.png
└── tests/
    ├── calculations.test.js
    └── ui-contract.test.js
```

## Pruebas locales

Requiere Node.js 18 o posterior. Desde esta carpeta:

```bash
node --test tests/*.test.js
node --check app.js
node --check calculations.js
node --check sw.js
```

Las 26 pruebas cubren ejemplos aritméticos, normalización de concentración desde mg/mL de etiqueta, entradas vacías/no numéricas, límites técnicos, frecuencias válidas e inválidas, resultados extremos, confirmación obligatoria para electrolitos, validación de ficha neonatal, separación de módulos e invalidación de resultados obsoletos. **No sustituyen pruebas en Safari/iOS, revisión farmacéutica ni validación clínica.**

## Instalación en iPhone mediante hosting HTTPS

Esta versión no está publicada. Para instalarla:

1. Descomprime `CMP_Cal_iPhone_PWA_v0.4.zip`.
2. Crea un repositorio propio en GitHub. Sube el contenido de la carpeta `cmp_cal_pwa` a la raíz del repositorio (no solo el ZIP).
3. En GitHub, abre **Settings → Pages**. En **Build and deployment**, selecciona **Deploy from a branch**, elige `main` y `/ (root)`, y guarda.
4. Espera a que GitHub Pages muestre la URL del sitio. Verifica que abra con `https://` y que cargue `index.html`.
5. Abre esa URL en Safari en el iPhone. Pulsa **Compartir → Añadir a pantalla de inicio** y confirma. Apple también permite activar **Abrir como app web** en el diálogo cuando esté disponible.
6. Abre CMP Cal con conexión al menos una vez. Después, prueba el modo avión para comprobar el shell offline. La disponibilidad real del almacenamiento depende del navegador/dispositivo.
7. Para actualizar, sube los archivos nuevos al repositorio. En cada versión cambia el identificador `CACHE` de `sw.js`; v0.4 usa `cmp-cal-v0.4`.

GitHub Pages puede servir sitios `github.io` mediante HTTPS; comprueba que la URL final use HTTPS antes de probar el service worker. No subas información de pacientes: GitHub Pages publica el contenido del repositorio como sitio web.

## Seguridad y límites pendientes

- No existe catálogo de medicamentos ni dosis terapéuticas precargadas.
- No hay verificación de concentración comercial, reconstitución, compatibilidad, velocidad de infusión ni ajustes renal/hepático.
- Los rangos de entrada son límites técnicos del formulario, no recomendaciones ni umbrales clínicos.
- La confirmación del operador para electrolitos no verifica el envase. Si hay cualquier duda sobre sal, hidratación, concentración o unidad, no usar la conversión.
- Los módulos matemáticos aún requieren revisión independiente por profesionales clínicos y farmacéuticos antes de cualquier uso asistencial.
- Falta prueba real en iPhone/Safari y validación del comportamiento offline en el dispositivo final.
- No se ha desplegado, publicado ni instalado esta PWA desde este proyecto.
