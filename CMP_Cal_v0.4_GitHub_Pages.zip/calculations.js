/* CMP Cal v0.4 — funciones matemáticas. No contiene pautas terapéuticas. */
(function (root) {
  'use strict';

  const MAX_WEIGHT_KG = 300; // límite técnico coherente con la interfaz; no es un umbral clínico
  const ELECTROLYTE_SALTS = Object.freeze({
    KCl: Object.freeze({ molecularWeight: 74.5513, valence: 1, label: 'KCl anhidro' }),
    NaCl: Object.freeze({ molecularWeight: 58.4428, valence: 1, label: 'NaCl anhidro' })
  });

  function positiveNumber(value, label) {
    if (value === null || value === undefined || (typeof value === 'string' && value.trim() === '')) {
      throw new Error(`${label}: campo obligatorio.`);
    }
    const number = Number(value);
    if (!Number.isFinite(number) || number <= 0) {
      throw new Error(`${label}: introduce un número mayor que cero.`);
    }
    return number;
  }

  function nonNegativeInteger(value, label) {
    if (value === null || value === undefined || (typeof value === 'string' && value.trim() === '')) {
      throw new Error(`${label}: campo obligatorio.`);
    }
    const number = Number(value);
    if (!Number.isInteger(number) || number < 0) {
      throw new Error(`${label}: introduce un número entero igual o mayor que cero.`);
    }
    return number;
  }

  function boundedWeight(value) {
    const weightKg = positiveNumber(value, 'Peso');
    if (weightKg > MAX_WEIGHT_KG) {
      throw new Error(`Peso: el límite técnico de esta calculadora es ${MAX_WEIGHT_KG} kg.`);
    }
    return weightKg;
  }

  function assertFinitePositiveResults(values) {
    if (!values.every(value => Number.isFinite(value) && value > 0)) {
      throw new Error('El resultado está fuera del rango calculable. Revisa los datos introducidos.');
    }
  }

  /** Normaliza la concentración declarada en etiqueta (mg por volumen indicado) a mg/mL. */
  function concentrationMgMl({ amountMg, volumeMl }) {
    const amount = positiveNumber(amountMg, 'Cantidad de medicamento');
    const volume = positiveNumber(volumeMl, 'Volumen correspondiente');
    const mgMl = amount / volume;
    assertFinitePositiveResults([mgMl]);
    return Object.freeze({ mgMl });
  }

  /** Convierte una dosis ya prescrita a mg y mL por administración. */
  function doseVolume({ weightKg, dose, concentrationMgMl, frequency, mode }) {
    const weight = boundedWeight(weightKg);
    const prescribedDose = positiveNumber(dose, 'Dosis');
    const concentration = positiveNumber(concentrationMgMl, 'Concentración');
    const administrationsPerDay = positiveNumber(frequency, 'Frecuencia');

    if (!Number.isInteger(administrationsPerDay) || administrationsPerDay > 24) {
      throw new Error('Frecuencia: usa un número entero de administraciones por día (1–24).');
    }
    if (mode !== 'per-dose' && mode !== 'per-day') {
      throw new Error('Selecciona un tipo de dosis válido.');
    }

    const dailyMg = weight * prescribedDose * (mode === 'per-dose' ? administrationsPerDay : 1);
    const perDoseMg = mode === 'per-dose' ? weight * prescribedDose : dailyMg / administrationsPerDay;
    const volumeMl = perDoseMg / concentration;
    assertFinitePositiveResults([dailyMg, perDoseMg, volumeMl]);
    return Object.freeze({ perDoseMg, dailyMg, volumeMl });
  }

  /** Estimación matemática de mantenimiento; no aplica a neonatos. */
  function maintenance({ weightKg, hours, method }) {
    const weight = boundedWeight(weightKg);
    const durationHours = positiveNumber(hours, 'Duración');
    if (![8, 24].includes(durationHours)) {
      throw new Error('La duración disponible es 8 o 24 horas.');
    }
    if (method !== 'holliday-segar' && method !== '4-2-1') {
      throw new Error('Selecciona un método válido.');
    }

    const hollidaySegarDailyMl = weight <= 10
      ? 100 * weight
      : weight <= 20
        ? 1000 + 50 * (weight - 10)
        : 1500 + 20 * (weight - 20);
    const fourTwoOneHourlyMl = weight <= 10
      ? 4 * weight
      : weight <= 20
        ? 40 + 2 * (weight - 10)
        : 60 + (weight - 20);
    const rateMlH = method === '4-2-1' ? fourTwoOneHourlyMl : hollidaySegarDailyMl / 24;
    const totalMl = rateMlH * durationHours;
    assertFinitePositiveResults([hollidaySegarDailyMl, fourTwoOneHourlyMl, rateMlH, totalMl]);

    return Object.freeze({
      rateMlH,
      totalMl,
      hollidaySegarDailyMl,
      fourTwoOneHourlyMl,
      methodDailyEquivalentMl: rateMlH * 24
    });
  }

  /**
   * Convierte % m/v de sal anhidra exacta a mEq.
   * Requiere confirmación explícita de que la etiqueta declara % m/v y la sal indicada.
   */
  function electrolyteMeq({ salt, percentWv, volumeMl, confirmedAnhydrousWv }) {
    if (confirmedAnhydrousWv !== true) {
      throw new Error('Confirma que la etiqueta indica % m/v de la sal anhidra exacta seleccionada.');
    }
    const spec = ELECTROLYTE_SALTS[salt];
    if (!spec) {
      throw new Error('Sal no admitida. Solo KCl o NaCl anhidros con identidad confirmada.');
    }
    const percent = positiveNumber(percentWv, 'Concentración');
    const volume = positiveNumber(volumeMl, 'Volumen');

    // % m/v = gramos de sal por 100 mL; mg/mL = porcentaje × 10.
    const mgMl = percent * 10;
    const meqMl = (mgMl * spec.valence) / spec.molecularWeight;
    const totalMeq = meqMl * volume;
    assertFinitePositiveResults([mgMl, meqMl, totalMeq]);
    return Object.freeze({ meqMl, totalMeq, saltLabel: spec.label });
  }

  /** Valida solo datos de identificación clínica; no clasifica ni calcula tratamiento. */
  function validateNeonatalProfile({ gestationalWeeks, postnatalDays, weightKg }) {
    const ga = positiveNumber(gestationalWeeks, 'Edad gestacional');
    const pna = nonNegativeInteger(postnatalDays, 'Edad posnatal');
    const weight = positiveNumber(weightKg, 'Peso actual');

    if (!Number.isInteger(ga) || ga < 20 || ga > 45) {
      throw new Error('Edad gestacional: introduce semanas completas entre 20 y 45.');
    }
    if (pna > 28) {
      throw new Error('Edad posnatal: introduce días completos entre 0 y 28.');
    }
    if (weight < 0.1 || weight > 10) {
      throw new Error('Peso neonatal: introduce un valor entre 0.1 y 10 kg.');
    }

    return Object.freeze({ gestationalWeeks: ga, postnatalDays: pna, weightKg: weight });
  }

  root.CMPCal = Object.freeze({
    concentrationMgMl,
    doseVolume,
    maintenance,
    electrolyteMeq,
    validateNeonatalProfile
  });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.CMPCal;
})(typeof globalThis !== 'undefined' ? globalThis : this);
