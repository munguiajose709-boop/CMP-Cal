# Informe de pruebas — CMP Cal v0.4

**Fecha de ejecución:** 24 de noviembre de 2026  
**Entorno:** Node.js 22.16.0  
**Resultado:** 26 pruebas aprobadas, 0 fallidas.

## Comprobaciones ejecutadas

- `npm test`: 26/26 pruebas correctas.
- `npm run check`: sintaxis válida en `app.js`, `calculations.js` y `sw.js`.
- HTML: 57 identificadores únicos; 22 referencias de etiquetas y ARIA resueltas; sin IDs duplicados.
- Manifiesto: JSON válido; `start_url` y `scope` relativos; iconos declarados presentes.
- ZIP: prueba de integridad completada sin errores.

## Alcance de las pruebas

Se cubren conversiones matemáticas, normalización de concentración desde la relación mg/mL de etiqueta, frecuencia, entradas inválidas, límites técnicos, mantenimiento teórico, conversión condicionada de KCl/NaCl, validación de la ficha neonatal, separación de módulos e invalidación de resultados al editar datos.

## No cubierto

- No se ejecutó en Safari/iOS ni en un iPhone físico.
- No se comprobó el service worker desde un dominio HTTPS real ni el modo avión del dispositivo.
- No se realizó validación clínica, farmacéutica o regulatoria.
- No se publicó ni desplegó el sitio.

Las pruebas de software no autorizan uso asistencial ni sustituyen revisión clínica independiente.
