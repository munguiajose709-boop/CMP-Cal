# Historial de cambios

## 0.4.0 — 24 de noviembre de 2026

- La concentración del medicamento se obtiene a partir de la relación de etiqueta en mg y mL (p. ej., 125 mg/5 mL), evitando exigir una conversión manual previa a mg/mL.
- El resultado muestra la concentración normalizada usada en el cálculo.
- La frecuencia pasa a ser un campo entero editable de 1–24 administraciones al día; ya no queda limitada a 1, 2, 3, 4 o 6.
- Los resultados se ocultan automáticamente al modificar datos o confirmaciones, para evitar mostrar cálculos obsoletos.
- El volumen por dosis se presenta con hasta seis cifras significativas para evitar redondear silenciosamente volúmenes pequeños a 0.000 mL.
- Se rechazan resultados que se desbordan numéricamente a cero o infinito.
- Se amplían pruebas de concentración, frecuencia, subdesbordamiento e invalidación visual.
- Se actualiza la versión del caché del service worker.

## 0.3.0 — 17 de noviembre de 2026

- Separación de estructura en `styles.css`, `app.js` y `calculations.js`.
- Navegación por pestañas con roles ARIA y controles de teclado.
- Validaciones centralizadas de campos obligatorios, números, frecuencia, duración y límites técnicos.
- Confirmación obligatoria para convertir una dosis ya prescrita.
- Confirmación obligatoria de etiqueta para KCl/NaCl anhidros expresados en % m/v.
- Ficha neonatal independiente con validación propia; sin dosis ni hidratación neonatal.
- Botones para limpiar cada módulo y mensajes de conexión/estado PWA.
- Service worker limitado al mismo origen, caché versionado y fallback offline solo para navegación.
- Pruebas automatizadas y guía de instalación en GitHub Pages.
