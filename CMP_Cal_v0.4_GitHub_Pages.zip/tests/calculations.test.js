const test = require('node:test');
const assert = require('node:assert/strict');
const calc = require('../calculations.js');

test('mg/kg/dosis: calcula mg y volumen por administración y total diario', () => {
  const r = calc.doseVolume({ weightKg: 10, dose: 15, concentrationMgMl: 125, frequency: 3, mode: 'per-dose' });
  assert.equal(r.perDoseMg, 150);
  assert.equal(r.dailyMg, 450);
  assert.equal(r.volumeMl, 1.2);
});

test('mg/kg/día: divide la cantidad diaria entre frecuencia', () => {
  const r = calc.doseVolume({ weightKg: 10, dose: 30, concentrationMgMl: 100, frequency: 2, mode: 'per-day' });
  assert.equal(r.dailyMg, 300);
  assert.equal(r.perDoseMg, 150);
  assert.equal(r.volumeMl, 1.5);
});

test('rechaza campos vacíos, no numéricos, no positivos y pesos fuera del límite técnico', () => {
  const invalid = [
    { weightKg: '', dose: 1, concentrationMgMl: 1, frequency: 1, mode: 'per-dose' },
    { weightKg: 1, dose: 'abc', concentrationMgMl: 1, frequency: 1, mode: 'per-dose' },
    { weightKg: 1, dose: -1, concentrationMgMl: 1, frequency: 1, mode: 'per-dose' },
    { weightKg: 301, dose: 1, concentrationMgMl: 1, frequency: 1, mode: 'per-dose' },
    { weightKg: 1, dose: 1, concentrationMgMl: 0, frequency: 1, mode: 'per-dose' }
  ];
  for (const input of invalid) assert.throws(() => calc.doseVolume(input));
});

test('rechaza frecuencia fraccionaria, fuera de rango y modo desconocido', () => {
  for (const frequency of [0, 1.5, 25]) {
    assert.throws(() => calc.doseVolume({ weightKg: 1, dose: 1, concentrationMgMl: 1, frequency, mode: 'per-dose' }));
  }
  assert.throws(() => calc.doseVolume({ weightKg: 1, dose: 1, concentrationMgMl: 1, frequency: 1, mode: 'other' }));
});

test('Holliday-Segar: 10 kg = 1000 mL/día y un tercio en 8 h', () => {
  const r = calc.maintenance({ weightKg: 10, hours: 8, method: 'holliday-segar' });
  assert.equal(r.hollidaySegarDailyMl, 1000);
  assert.equal(r.rateMlH, 1000 / 24);
  assert.equal(r.totalMl, 1000 / 3);
});

test('4-2-1: 25 kg = 65 mL/h y 1560 mL equivalentes en 24 h', () => {
  const r = calc.maintenance({ weightKg: 25, hours: 24, method: '4-2-1' });
  assert.equal(r.rateMlH, 65);
  assert.equal(r.totalMl, 1560);
  assert.equal(r.methodDailyEquivalentMl, 1560);
});

test('rechaza duración y método de mantenimiento no admitidos', () => {
  assert.throws(() => calc.maintenance({ weightKg: 10, hours: 12, method: 'holliday-segar' }));
  assert.throws(() => calc.maintenance({ weightKg: 10, hours: 8, method: 'unknown' }));
});

test('KCl 15% m/v anhidro, 10 mL ≈ 20.12 mEq solo con confirmación', () => {
  const r = calc.electrolyteMeq({ salt: 'KCl', percentWv: 15, volumeMl: 10, confirmedAnhydrousWv: true });
  assert.ok(Math.abs(r.totalMeq - 20.12) < 0.02);
  assert.ok(Math.abs(r.meqMl - 2.012) < 0.002);
  assert.throws(() => calc.electrolyteMeq({ salt: 'KCl', percentWv: 15, volumeMl: 10, confirmedAnhydrousWv: false }));
});

test('NaCl 0.9% m/v anhidro, 100 mL ≈ 15.40 mEq', () => {
  const r = calc.electrolyteMeq({ salt: 'NaCl', percentWv: 0.9, volumeMl: 100, confirmedAnhydrousWv: true });
  assert.ok(Math.abs(r.totalMeq - 15.40) < 0.02);
});

test('bloquea sales no admitidas y entradas electrolíticas inválidas', () => {
  assert.throws(() => calc.electrolyteMeq({ salt: 'MgSO4', percentWv: 10, volumeMl: 1, confirmedAnhydrousWv: true }));
  assert.throws(() => calc.electrolyteMeq({ salt: 'KCl', percentWv: 10, volumeMl: 0, confirmedAnhydrousWv: true }));
  assert.throws(() => calc.electrolyteMeq({ salt: 'NaCl', percentWv: '', volumeMl: 1, confirmedAnhydrousWv: true }));
});

test('ficha neonatal valida semanas, días y peso sin calcular dosis', () => {
  const r = calc.validateNeonatalProfile({ gestationalWeeks: 34, postnatalDays: 2, weightKg: 2.45 });
  assert.deepEqual(r, { gestationalWeeks: 34, postnatalDays: 2, weightKg: 2.45 });
});

test('ficha neonatal rechaza días fraccionarios, fuera de rango y campos vacíos', () => {
  for (const input of [
    { gestationalWeeks: 34, postnatalDays: 1.5, weightKg: 2 },
    { gestationalWeeks: 19, postnatalDays: 1, weightKg: 2 },
    { gestationalWeeks: 34, postnatalDays: 29, weightKg: 2 },
    { gestationalWeeks: 34, postnatalDays: 1, weightKg: 0.05 },
    { gestationalWeeks: '', postnatalDays: 1, weightKg: 2 },
    { gestationalWeeks: 34, postnatalDays: '', weightKg: 2 }
  ]) assert.throws(() => calc.validateNeonatalProfile(input));
});

test('normaliza concentración de etiqueta: 125 mg en 5 mL = 25 mg/mL', () => {
  const r = calc.concentrationMgMl({ amountMg: 125, volumeMl: 5 });
  assert.equal(r.mgMl, 25);
});

test('normaliza concentración ya expresada por mL sin cambiar el valor', () => {
  const r = calc.concentrationMgMl({ amountMg: 40, volumeMl: 1 });
  assert.equal(r.mgMl, 40);
});

test('rechaza cantidad o volumen de concentración vacíos, no positivos o no finitos', () => {
  const invalid = [
    { amountMg: '', volumeMl: 5 },
    { amountMg: 125, volumeMl: '' },
    { amountMg: 0, volumeMl: 5 },
    { amountMg: 125, volumeMl: 0 },
    { amountMg: -1, volumeMl: 5 },
    { amountMg: 125, volumeMl: Infinity }
  ];
  for (const input of invalid) assert.throws(() => calc.concentrationMgMl(input));
});

test('acepta frecuencias enteras distintas de las opciones predefinidas, como 8 al día', () => {
  const r = calc.doseVolume({ weightKg: 10, dose: 1, concentrationMgMl: 10, frequency: 8, mode: 'per-dose' });
  assert.equal(r.dailyMg, 80);
  assert.equal(r.volumeMl, 1);
});

test('rechaza resultados que se subdesbordan a cero por entradas extremas', () => {
  assert.throws(() => calc.doseVolume({ weightKg: 1e-300, dose: 1e-300, concentrationMgMl: 1, frequency: 1, mode: 'per-dose' }));
});


test('flujo completo de concentración de etiqueta a volumen por dosis', () => {
  const concentration = calc.concentrationMgMl({ amountMg: 120, volumeMl: 5 });
  const dose = calc.doseVolume({
    weightKg: 10,
    dose: 15,
    concentrationMgMl: concentration.mgMl,
    frequency: 3,
    mode: 'per-dose'
  });
  assert.equal(concentration.mgMl, 24);
  assert.equal(dose.perDoseMg, 150);
  assert.equal(dose.volumeMl, 6.25);
  assert.equal(dose.dailyMg, 450);
});
