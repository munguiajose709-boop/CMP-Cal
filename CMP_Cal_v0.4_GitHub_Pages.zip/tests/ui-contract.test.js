const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const app = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const sw = fs.readFileSync(path.join(__dirname, '..', 'sw.js'), 'utf8');

test('los cuatro módulos y sus paneles accesibles están presentes', () => {
  for (const id of ['dose', 'fluids', 'electro', 'neo']) {
    assert.match(html, new RegExp(`id="${id}"`));
    assert.match(html, new RegExp(`aria-controls="${id}"`));
  }
  assert.match(html, /role="tablist"/);
  assert.match(html, /role="tabpanel"/);
});

test('neonatología tiene validación propia y no invoca calculadora pediátrica', () => {
  assert.match(html, /id="validateNeo"/);
  assert.match(app, /CMPCal\.validateNeonatalProfile/);
  const neoHandler = app.split("$('validateNeo')")[1].split("const resetDefinitions")[0];
  assert.doesNotMatch(neoHandler, /doseVolume|maintenance|electrolyteMeq/);
});

test('electrolitos requieren confirmación explícita de sal y porcentaje', () => {
  assert.match(html, /id="electroConfirmed"/);
  assert.match(app, /confirmedAnhydrousWv: \$\('electroConfirmed'\)\.checked/);
});

test('la app separa CSS y JavaScript y no usa manejadores inline', () => {
  assert.match(html, /href="styles\.css"/);
  assert.match(html, /src="calculations\.js" defer/);
  assert.match(html, /src="app\.js" defer/);
  assert.doesNotMatch(html, /\sonclick=/i);
});

test('service worker limita fetch al mismo origen y usa caché versionado', () => {
  assert.match(sw, /cmp-cal-v0\.4/);
  assert.match(sw, /url\.origin !== self\.location\.origin/);
  assert.match(sw, /request\.mode === 'navigate'/);
});

test('concentración se calcula desde mg y mL declarados en la etiqueta', () => {
  assert.match(html, /id="concMg"/);
  assert.match(html, /id="concVolume"/);
  assert.match(app, /CMPCal\.concentrationMgMl/);
  assert.match(html, /id="doseConc"/);
  assert.match(app, /doseConc.*textContent/);
});

test('frecuencia es un entero editable de 1 a 24 administraciones al día', () => {
  assert.match(html, /id="freq" type="number" min="1" max="24" step="1"/);
});

test('los resultados se invalidan cuando cambia cualquier campo del módulo', () => {
  assert.match(app, /invalidationDefinitions/);
  assert.match(app, /field\.addEventListener\(eventName, \(\) => clearResult/);
});
