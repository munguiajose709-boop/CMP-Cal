CMP Cal v0.4 - archivos para GitHub Pages

Sube TODOS los archivos y carpetas de este paquete a la RAIZ del repositorio.
No subas la carpeta contenedora cmp_cal_pwa: index.html debe quedar en la raiz.

Archivos necesarios:
index.html, app.js, calculations.js, styles.css,
manifest.webmanifest, sw.js, icon-192.png, icon-512.png.

Luego en GitHub: Settings > Pages > Deploy from a branch > main > /(root) > Save.
Espera a que GitHub publique el sitio HTTPS.
