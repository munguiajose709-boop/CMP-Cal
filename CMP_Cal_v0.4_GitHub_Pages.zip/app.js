'use strict';

const $ = id => document.getElementById(id);
const showError = (id, message) => { $(id).textContent = message; };
const hide = id => $(id).classList.add('hidden');
const show = id => $(id).classList.remove('hidden');
const fmt = (number, digits = 2) => new Intl.NumberFormat('es-NI', {
  minimumFractionDigits: digits,
  maximumFractionDigits: digits
}).format(number);
const fmtSignificant = number => new Intl.NumberFormat('es-NI', {
  maximumSignificantDigits: 6
}).format(number);

function clearResult(resultId, errorId) {
  hide(resultId);
  showError(errorId, '');
}

function clearFields(ids) {
  ids.forEach(id => {
    const field = $(id);
    if (!field) return;
    if (field.type === 'checkbox') field.checked = false;
    else if (field.tagName === 'SELECT') field.selectedIndex = 0;
    else field.value = '';
  });
}

// Navegación accesible: pediatría, hidratación, electrolitos y neonatología son paneles separados.
const tabs = [...document.querySelectorAll('[data-page]')];
const pages = [...document.querySelectorAll('.page')];
function activatePage(pageId) {
  tabs.forEach((tab, index) => {
    const selected = tab.dataset.page === pageId;
    tab.setAttribute('aria-selected', String(selected));
    tab.tabIndex = selected ? 0 : -1;
    if (selected) tab.focus({ preventScroll: true });
  });
  pages.forEach(page => {
    const active = page.id === pageId;
    page.classList.toggle('hidden', !active);
    page.hidden = !active;
  });
}
tabs.forEach((tab, index) => {
  tab.addEventListener('click', () => activatePage(tab.dataset.page));
  tab.addEventListener('keydown', event => {
    if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault();
    let next = index;
    if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
    if (event.key === 'ArrowLeft') next = (index - 1 + tabs.length) % tabs.length;
    if (event.key === 'Home') next = 0;
    if (event.key === 'End') next = tabs.length - 1;
    activatePage(tabs[next].dataset.page);
  });
});

$('calcDose').addEventListener('click', () => {
  clearResult('doseResult', 'doseError');
  try {
    if (!$('doseConfirmed').checked) throw new Error('Confirma que estás convirtiendo una dosis previamente prescrita.');
    const concentration = CMPCal.concentrationMgMl({
      amountMg: $('concMg').value,
      volumeMl: $('concVolume').value
    });
    const result = CMPCal.doseVolume({
      weightKg: $('weight').value,
      dose: $('doseValue').value,
      concentrationMgMl: concentration.mgMl,
      frequency: $('freq').value,
      mode: $('doseType').value
    });
    $('doseMl').textContent = `${fmtSignificant(result.volumeMl)} mL`;
    $('doseConc').textContent = `${fmtSignificant(concentration.mgMl)} mg/mL`;
    $('doseMg').textContent = `${fmt(result.perDoseMg, 2)} mg`;
    $('dailyMg').textContent = `${fmt(result.dailyMg, 2)} mg/día`;
    show('doseResult');
  } catch (error) {
    showError('doseError', error.message);
  }
});

$('calcFluid').addEventListener('click', () => {
  clearResult('fluidResult', 'fluidError');
  try {
    if (!$('fluidConfirmed').checked) throw new Error('Confirma que el paciente no es neonato y que esta estimación es apropiada para revisar.');
    const result = CMPCal.maintenance({
      weightKg: $('fluidWeight').value,
      hours: $('duration').value,
      method: $('fluidMethod').value
    });
    $('fluidMl').textContent = `${fmt(result.totalMl, 1)} mL / ${$('duration').value} h`;
    $('fluidRate').textContent = `${fmt(result.rateMlH, 1)} mL/h`;
    $('fluidDaily').textContent = `${fmt(result.methodDailyEquivalentMl, 1)} mL/24 h equivalentes`;
    show('fluidResult');
  } catch (error) {
    showError('fluidError', error.message);
  }
});

$('calcElectro').addEventListener('click', () => {
  clearResult('electroResult', 'electroError');
  try {
    const result = CMPCal.electrolyteMeq({
      salt: $('salt').value,
      percentWv: $('percent').value,
      volumeMl: $('volume').value,
      confirmedAnhydrousWv: $('electroConfirmed').checked
    });
    $('meq').textContent = `${fmt(result.totalMeq, 2)} mEq`;
    $('meqPerMl').textContent = `${fmt(result.meqMl, 4)} mEq/mL`;
    $('electroSaltLabel').textContent = result.saltLabel;
    show('electroResult');
  } catch (error) {
    showError('electroError', error.message);
  }
});

$('validateNeo').addEventListener('click', () => {
  clearResult('neoResult', 'neoError');
  try {
    const profile = CMPCal.validateNeonatalProfile({
      gestationalWeeks: $('ga').value,
      postnatalDays: $('pna').value,
      weightKg: $('neoWeight').value
    });
    $('neoGaResult').textContent = `${profile.gestationalWeeks} semanas`;
    $('neoPnaResult').textContent = `${profile.postnatalDays} días`;
    $('neoWeightResult').textContent = `${fmt(profile.weightKg, 3)} kg`;
    show('neoResult');
  } catch (error) {
    showError('neoError', error.message);
  }
});

const resetDefinitions = {
  resetDose: { fields: ['weight', 'concMg', 'concVolume', 'doseValue', 'doseType', 'freq', 'doseConfirmed'], result: 'doseResult', error: 'doseError' },
  resetFluid: { fields: ['fluidWeight', 'duration', 'fluidMethod', 'fluidConfirmed'], result: 'fluidResult', error: 'fluidError' },
  resetElectro: { fields: ['salt', 'percent', 'volume', 'electroConfirmed'], result: 'electroResult', error: 'electroError' },
  resetNeo: { fields: ['ga', 'pna', 'neoWeight'], result: 'neoResult', error: 'neoError' }
};
Object.entries(resetDefinitions).forEach(([buttonId, definition]) => {
  $(buttonId).addEventListener('click', () => {
    clearFields(definition.fields);
    clearResult(definition.result, definition.error);
  });
});


// Invalida resultados cuando cambia cualquier dato: evita mostrar cálculos obsoletos.
const invalidationDefinitions = [
  { fields: ['weight', 'concMg', 'concVolume', 'doseValue', 'doseType', 'freq', 'doseConfirmed'], result: 'doseResult', error: 'doseError' },
  { fields: ['fluidWeight', 'duration', 'fluidMethod', 'fluidConfirmed'], result: 'fluidResult', error: 'fluidError' },
  { fields: ['salt', 'percent', 'volume', 'electroConfirmed'], result: 'electroResult', error: 'electroError' },
  { fields: ['ga', 'pna', 'neoWeight'], result: 'neoResult', error: 'neoError' }
];
invalidationDefinitions.forEach(definition => {
  definition.fields.forEach(id => {
    const field = $(id);
    const eventName = field.type === 'checkbox' || field.tagName === 'SELECT' ? 'change' : 'input';
    field.addEventListener(eventName, () => clearResult(definition.result, definition.error));
  });
});

function updateConnectionStatus() {
  const status = $('connectionStatus');
  status.textContent = navigator.onLine
    ? 'Conexión de red detectada'
    : 'Sin conexión de red detectada';
  status.dataset.online = String(navigator.onLine);
}
window.addEventListener('online', updateConnectionStatus);
window.addEventListener('offline', updateConnectionStatus);
updateConnectionStatus();

if ('serviceWorker' in navigator && window.isSecureContext) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js', { scope: './' })
      .then(() => navigator.serviceWorker.ready)
      .then(() => { $('pwaStatus').textContent = 'Service worker activo · prueba offline pendiente en el dispositivo'; })
      .catch(() => { $('pwaStatus').textContent = 'No se pudo activar el modo sin conexión en este origen.'; });
  });
} else {
  $('pwaStatus').textContent = 'Modo sin conexión no disponible: requiere un origen seguro HTTPS (o localhost de desarrollo).';
}
